# -*- coding: utf-8 -*-
"""Define container dependencies.
"""
dependencies = {
}
